import colors from "./colors";
import fontType from "./fonts";
import colors from "./colors";
import fontType from "./fonts";
export {colors, fontType}; 